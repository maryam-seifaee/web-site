		<!-- load JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script> 
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/js/script.js"></script>
	</body>
</html>