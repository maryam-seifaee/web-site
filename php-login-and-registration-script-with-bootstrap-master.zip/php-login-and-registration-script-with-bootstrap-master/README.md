# PHP & Bootstrap User authentication system with basic social media features

Welcome 

<strong>
This project will no longer be updated (as of 11/06/17).  I have now created a new project that better matches the scope of how this project was progressing.  The new project can be found by visiting this link: https://github.com/MattN1014/Chat-It
</strong>

<hr>


This system could be used for a number of different applications and easily integrated into any projects you may be thinking of creating.  

I have used PHP PDO, JS, HTML, CSS to create this system.  The basic functions are to: 
<ul>
<li>Create a user (Register)</li>
<li>Login a user</li> 
<li>Reset a users password</li> 
<li>Show a basic profile of the logged in user.</li>  
<li>Enabled basic profile editing (username & email address).</li>
</ul>

 
I have included the SQL DB i currently have for this project.  There is one user currently registered, however you can easily create a new user to register.  When i have finished creating the system as far as the scope of this project goes.  I will upload a new SQL DB with no registered users. 

If you want to integrate this system into any of your projects please feel free to do so.  If you want to make any changes to the project files then please feel free to do so.  
 



  
